from .model import train_model, predict_next_word, auto_complete
